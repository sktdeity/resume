package onlyfun.caterpillar;
 
import java.io.*; 
import javax.servlet.*; 
import javax.servlet.http.*; 
 
public class HelloServlet extends HttpServlet { 
    public void doGet(HttpServletRequest req, 
                      HttpServletResponse res) 
                  throws ServletException, IOException { 
        res.setContentType("text/html"); 
        PrintWriter out = res.getWriter(); 
 
        out.println("<html>"); 
        out.println("<head>");
        out.println("<title>Hello!Servlet!</title>");
        out.println("</head>"); 
        out.println("<body>"); 
        out.println("<h1><b>Hello!Servlet!</b></h1>"); 
        out.println("</body>"); 
        out.println("</html>"); 
    } 
}